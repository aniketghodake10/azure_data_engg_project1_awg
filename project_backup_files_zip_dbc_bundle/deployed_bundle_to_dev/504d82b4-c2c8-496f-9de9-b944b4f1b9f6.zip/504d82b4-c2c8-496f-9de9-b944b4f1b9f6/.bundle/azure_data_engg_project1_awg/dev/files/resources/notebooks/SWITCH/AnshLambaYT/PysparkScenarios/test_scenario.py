# Databricks notebook source
# MAGIC %sql
# MAGIC describe history pyspark_scenarios_catalog.source.products_test1141 

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history delta.`/Volumes/pyspark_scenarios_catalog/source/db_volume/managed_tables_dir/products_test1141/sink/data11411`