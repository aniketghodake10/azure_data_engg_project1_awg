# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

service_credential = dbutils.secrets.get(scope='scope-test-learning-awg', key='azure-ms-entra-secret-key-vault-governance-awg')
 
spark.conf.set("fs.azure.account.auth.type.datalaketestlearningawg.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.datalaketestlearningawg.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.datalaketestlearningawg.dfs.core.windows.net", "504d82b4-c2c8-496f-9de9-b944b4f1b9f6")
spark.conf.set("fs.azure.account.oauth2.client.secret.datalaketestlearningawg.dfs.core.windows.net", service_credential)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.datalaketestlearningawg.dfs.core.windows.net", "https://login.microsoftonline.com/50a3af05-f42e-4ad1-9203-9b4d0f7b4664/oauth2/token")

# COMMAND ----------

schemaa = """
id bigint,
case_number string,
Date timestamp,
Block string,
IUCR string,
Primary_Type string,
Description string,
Location_Description string,
Arrest string,
Domestic string,
Beat string,
District string,
Ward string,
Community_Area string,
FBI_Code string,
X_Coordinate double,
Y_Coordinate double,
Year string,
Updated_On timestamp,
Latitude string,
Longitude string,
Location string
"""

# COMMAND ----------

df = spark.read.format('csv').schema(schemaa).option('header', 'true').load('abfss://adf-swdi-s3-1@datalaketestlearningawg.dfs.core.windows.net/source/api/views/ijzp-q8t2/rows.csvf89568009b486b640412bba863bc45a11f8efc9396029c714dda494910a90164')

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.select(spark_partition_id()).distinct().count()

# COMMAND ----------

df.write.format('delta').mode('overwrite').saveAsTable('main.default.chicago_crimes2')
#option('optimizeWrite', 'true')

# COMMAND ----------

df.repartition(6, 'id')

# COMMAND ----------

df.write.format('delta').option('optimizeWrite', 'true').mode('overwrite').saveAsTable('main.default.chicago_crimes3')

# COMMAND ----------

df.write.format('delta').partitionBy('Primary_Type').option('optimizeWrite', 'true').mode('overwrite').saveAsTable('main.default.chicago_crimes4')

# COMMAND ----------

spark.conf.get("spark.sql.files.maxPartitionBytes")

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize main.default.chicago_crimes2 zorder by id

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL main.default.chicago_crimes2;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL main.default.chicago_crimes3;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DETAIL main.default.chicago_crimes4;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.default.chicago_crimes1 limit 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select current_user()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table main.default.chicago_crimes5 as select * from main.default.chicago_crimes4
# MAGIC cluster by id
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE main.default.chicago_crimes5 FULL

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table main.default.chicago_crimes5 set tblproperties (delta.autoOptimize.optimizeWrite = true, delta.autoOptimize.autoCompact = true);

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table main.default.chicago_crimes5 cluster by AUTO;

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE main.default.chicago_crimes5 FULL;

# COMMAND ----------

from pyspark.sql.functions import udtf
@udtf(returnType="splitted_block: string")
class SplitterClass:
    def eval(self, text):
        for tex in text.split():
            yield (tex,)
# udtf_text_splitter = udtf(SplitterClass, returnType="splitted_block: string")

# COMMAND ----------

spark.udtf.register("sql_udtf_text_splitter", SplitterClass)

# COMMAND ----------

# MAGIC %sql
# MAGIC select b.splitted_block,
# MAGIC a.* 
# MAGIC from main.default.chicago_crimes5 a,
# MAGIC lateral sql_udtf_text_splitter(a.BLOCK) as b
# MAGIC limit 5

# COMMAND ----------

# MAGIC %sql
# MAGIC select b.splitted_block,
# MAGIC a.* 
# MAGIC from main.default.chicago_crimes5 a
# MAGIC join lateral sql_udtf_text_splitter(a.BLOCK) as b
# MAGIC limit 5

# COMMAND ----------

# MAGIC %sql
# MAGIC select b.splitted_block,
# MAGIC a.* 
# MAGIC from main.default.chicago_crimes5 a
# MAGIC join lateral (select * from sql_udtf_text_splitter(a.BLOCK)) as b
# MAGIC limit 5

# COMMAND ----------

SplitterClass(lit("HI BYE")).show()

# COMMAND ----------

import pandas as pd
from pyspark.sql.functions import pandas_udf, lit
@pandas_udf("integer")
def vectorized_square(s):
    return s * s
vectorized_square(lit(5)).show()

# COMMAND ----------

import pandas as pd
from pyspark.sql.functions import pandas_udf, lit
@pandas_udf("integer")
def vectorized_square(s):
    return s * s
spark.createDataFrame([(5,),(6,),(7,),(8,),(9,),(5,),(5,)], ['value']).select(vectorized_square('value')).show()

# COMMAND ----------

def square_func(n):
    return n * n if n is not None else None
square_func(lit(5)).show()

# COMMAND ----------

def square_func(n):
    return n * n if n is not None else None
spark.createDataFrame([(5,),(6,),(7,),(8,),(9,),(5,),(5,)], ['value']).select(square_func('value')).show()

# COMMAND ----------

def square_func(n):
    return n * n if n is not None else None
spark.createDataFrame([(5,),(6,),(7,),(8,),(9,),(5,),(5,)], ['value']).select(square_func(col('value'))).show()

# COMMAND ----------

# MAGIC %sql
# MAGIC select D1.DeptName, jl.EmpName,jl.Salary
# MAGIC FROM main.default.Department D1
# MAGIC join lateral (
# MAGIC select * from main.default.Employee e1
# MAGIC where E1.DeptID = D1.DeptID
# MAGIC order by e1.salary desc
# MAGIC limit 2
# MAGIC ) as jl