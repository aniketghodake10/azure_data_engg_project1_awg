-- Databricks notebook source
-- CREATE TABLE users (
--     user_id INT,
--     user_name STRING
-- );

-- INSERT INTO users VALUES
-- (1, 'Alice'),
-- (2, 'Bob'),
-- (3, 'Charlie');

-- CREATE TABLE orders (
--     order_id INT,
--     user_id INT,
--     amount INT,
--     order_date DATE
-- );

-- INSERT INTO orders VALUES
-- (101, 1, 50,  '2023-01-01'),
-- (102, 1, 150, '2023-01-05'),
-- (103, 2, 20,  '2023-01-02'),
-- (104, 2, 80,  '2023-01-04'),
-- (105, 3, 200, '2023-01-01');

-- -- Create Department Table
-- CREATE TABLE Department (
--     DeptID INT PRIMARY KEY,
--     DeptName VARCHAR(50)
-- );

-- -- Create Employee Table
-- CREATE TABLE Employee (
--     EmpID INT PRIMARY KEY,
--     EmpName VARCHAR(100),
--     Salary DECIMAL(10, 2),
--     DeptID INT,
--     FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
-- );

-- -- Insert Departments
-- INSERT INTO Department (DeptID, DeptName) VALUES 
-- (1, 'IT'), 
-- (2, 'HR'), 
-- (3, 'Finance');

-- -- Insert Employees
-- INSERT INTO Employee (EmpID, EmpName, Salary, DeptID) VALUES 
-- (101, 'Alice', 90000, 1),
-- (102, 'Bob', 85000, 1),
-- (103, 'Charlie', 95000, 1),
-- (104, 'David', 60000, 2),
-- (105, 'Eve', 75000, 2),
-- (106, 'Frank', 75000, 2),
-- (107, 'Grace', 80000, 3);
