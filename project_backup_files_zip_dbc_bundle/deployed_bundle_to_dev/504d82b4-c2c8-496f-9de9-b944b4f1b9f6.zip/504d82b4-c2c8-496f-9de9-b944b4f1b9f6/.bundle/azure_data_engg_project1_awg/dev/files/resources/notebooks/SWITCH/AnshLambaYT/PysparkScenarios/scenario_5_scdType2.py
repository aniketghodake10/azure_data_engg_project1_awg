# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %sql
# MAGIC -- BY DEFAULT - DELTA
# MAGIC create table pyspark_scenarios_catalog.source.productsscd2src
# MAGIC as select * from pyspark_scenarios_catalog.source.products

# COMMAND ----------

df = spark.read.table('pyspark_scenarios_catalog.source.productsscd2src')

df = df.withColumn('EffectiveStartDate', col('updatedDate')).withColumn('EffectiveEndDate', lit('4712-12-31').cast('timestamp')).withColumn('isActive', lit('Y'))

df.write.saveAsTable('pyspark_scenarios_catalog.destination.productsscd2trg')

# COMMAND ----------

# DEDUP

df_src = spark.sql("""
                   select * from (
                   select *, max(updatedDate) over (partition by id) as max_update_date
                   from pyspark_scenarios_catalog.source.productsscd2src
                   ) cc where cc.updatedDate = cc.max_update_date
                   """)
df_src.createOrReplaceTempView('src')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from src

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into pyspark_scenarios_catalog.destination.productsscd2trg trg
# MAGIC using src
# MAGIC on trg.id = src.id
# MAGIC and trg.isActive = 'Y'
# MAGIC
# MAGIC when matched
# MAGIC --and other conditions
# MAGIC and trg.updatedDate <> src.updatedDate
# MAGIC then update set trg.isActive = 'N',
# MAGIC trg.EffectiveEndDate = src.updatedDate;
# MAGIC
# MAGIC merge into pyspark_scenarios_catalog.destination.productsscd2trg trg
# MAGIC using src
# MAGIC on trg.id = src.id
# MAGIC and trg.isActive = 'Y'
# MAGIC
# MAGIC when not matched
# MAGIC then insert (id, name, price, category, updatedDate, EffectiveStartDate, EffectiveEndDate, isActive)
# MAGIC values (src.id, src.name, src.price, src.category, src.updatedDate, src.updatedDate, timestamp '4712-12-31', 'Y')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pyspark_scenarios_catalog.destination.productsscd2trg
# MAGIC order by id, updatedDate

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pyspark_scenarios_catalog.destination.productsscd2trg
# MAGIC where isActive='Y'
# MAGIC order by id, updatedDate

# COMMAND ----------

df_trg = spark.sql("""
                   select * from pyspark_scenarios_catalog.destination.productsscd2trg
                   """)
df_trg.write.format('delta').option('inferSchema', 'true').save('/Volumes/pyspark_scenarios_catalog/source/db_volume/scd2_merge_delta_tbl')

# COMMAND ----------

# MERGE - will only work with Delta Table
from delta.tables import DeltaTable

dlt_tbl_obj = DeltaTable.forPath(spark, '/Volumes/pyspark_scenarios_catalog/source/db_volume/scd2_merge_delta_tbl/')


dlt_tbl_obj.alias('trg').merge(
    df_src.alias('src'),
    "src.id = trg.id and cast(trg.EffectiveEndDate as date) = to_date('4712-12-31')"
).whenMatchedUpdate(condition="trg.updatedDate != src.updatedDate",
                    set = {"EffectiveEndDate":"src.updatedDate"})\
    .execute()

dlt_tbl_obj.alias('trg').merge(
    df_src.alias('src'),
    "src.id = trg.id and cast(trg.EffectiveEndDate as date) = to_date('4712-12-31')"
).whenNotMatchedInsert(values = {"id":"src.id", "name":"src.name", "price":"src.price", "category":"src.category", "updatedDate":"src.updatedDate", "EffectiveStartDate":"src.updatedDate", "EffectiveEndDate":"to_timestamp('4712-12-31')"})\
    .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC --truncate table delta.`/Volumes/pyspark_scenarios_catalog/source/db_volume/scd2_merge_delta_tbl`
# MAGIC select * from delta.`/Volumes/pyspark_scenarios_catalog/source/db_volume/scd2_merge_delta_tbl`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/pyspark_scenarios_catalog/source/db_volume/scd2_merge_delta_tbl`

# COMMAND ----------

print(1)