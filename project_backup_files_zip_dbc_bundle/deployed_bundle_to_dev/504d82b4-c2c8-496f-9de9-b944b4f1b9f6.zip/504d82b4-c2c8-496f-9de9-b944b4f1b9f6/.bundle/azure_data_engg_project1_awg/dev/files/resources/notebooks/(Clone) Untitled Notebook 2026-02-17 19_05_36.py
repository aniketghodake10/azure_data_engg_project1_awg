# Databricks notebook source
print(dbutils.widgets.get("notebook_param1"))

# COMMAND ----------

print(dbutils.widgets.get("job_param1"))

# COMMAND ----------

print(dbutils.widgets.get("notebook_param2"))

# COMMAND ----------

try:
    print(dbutils.widgets.get("job_param2"))
except Exception as e:
    print("job_param2 not set, becasue this notebook is in job1",e, sep="\n")

# COMMAND ----------

print("ANIKET the BOSS")