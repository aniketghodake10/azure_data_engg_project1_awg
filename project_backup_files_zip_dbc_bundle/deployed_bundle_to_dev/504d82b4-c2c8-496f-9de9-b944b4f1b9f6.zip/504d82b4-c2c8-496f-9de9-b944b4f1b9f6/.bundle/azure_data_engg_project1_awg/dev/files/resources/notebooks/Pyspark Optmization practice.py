# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.storagelevel import StorageLevel


# COMMAND ----------

service_credential = dbutils.secrets.get(scope='scope-test-learning-awg', key='azure-ms-entra-secret-key-vault-governance-awg')
 
spark.conf.set("fs.azure.account.auth.type.datalaketestlearningawg.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.datalaketestlearningawg.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.datalaketestlearningawg.dfs.core.windows.net", "504d82b4-c2c8-496f-9de9-b944b4f1b9f6")
spark.conf.set("fs.azure.account.oauth2.client.secret.datalaketestlearningawg.dfs.core.windows.net", service_credential)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.datalaketestlearningawg.dfs.core.windows.net", "https://login.microsoftonline.com/50a3af05-f42e-4ad1-9203-9b4d0f7b4664/oauth2/token")

# COMMAND ----------

df = spark.read.format('csv').option("header", "true").option("inferSchema", "true").load("abfss://test-container3@datalaketestlearningawg.dfs.core.windows.net/testdir1/sales.csv")
df.show(2)

# COMMAND ----------

print(df.select(spark_partition_id()).distinct().count())

# COMMAND ----------

spark.conf.get("spark.sql.adaptive.enabled")

# COMMAND ----------

df = df.repartition(2)
print(df.select(spark_partition_id()).distinct().count())

# COMMAND ----------

df.collect()

# COMMAND ----------

df.persist(StorageLevel.MEMORY_ONLY)

# COMMAND ----------

df.collect()

# COMMAND ----------

df.unpersist()

# COMMAND ----------

df