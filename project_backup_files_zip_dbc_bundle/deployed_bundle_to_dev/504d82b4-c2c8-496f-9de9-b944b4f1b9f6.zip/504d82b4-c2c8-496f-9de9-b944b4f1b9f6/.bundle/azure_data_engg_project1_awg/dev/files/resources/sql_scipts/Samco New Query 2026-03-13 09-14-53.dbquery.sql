-- Databricks notebook source
select * from samco_1m_candles_RELIANCE
order by trade_time desc

truncate table samco_1m_candles_RELIANCE

-- create table backup_samco_1m_candles_RELIANCE as
-- select * from samco_1m_candles_RELIANCE

select * from backup_samco_1m_candles_RELIANCE