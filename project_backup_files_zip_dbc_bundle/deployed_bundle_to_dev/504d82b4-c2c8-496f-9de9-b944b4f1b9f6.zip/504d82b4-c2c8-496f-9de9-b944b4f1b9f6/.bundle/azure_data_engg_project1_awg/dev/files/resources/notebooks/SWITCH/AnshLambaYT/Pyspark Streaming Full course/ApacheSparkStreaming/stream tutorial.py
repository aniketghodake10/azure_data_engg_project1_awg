# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Read Streaming Data**

# COMMAND ----------

my_schema = """order_id STRING,
        timestamp STRING,
        customer STRUCT<
          customer_id: INT,
          name: STRING,
          email: STRING,
          address: STRUCT<
            city: STRING,
            postal_code: STRING,
            country: STRING
          >
        >,
        items ARRAY<STRUCT<
          item_id: STRING,
          product_name: STRING,
          quantity: INT,
          price: DOUBLE
        >>,
        payment STRUCT<
          method: STRING,
          transaction_id: STRING
        >,
        metadata ARRAY<STRUCT<
          key: STRING,
          value: STRING
        >>"""

# COMMAND ----------

df = spark.readStream.format("json")\
          .option("multiLine",True)\
          .schema(my_schema)\
          .load("/Volumes/workspace/stream/streaming/jsonsource")


# Transformations
df = df.select("items","order_id","timestamp","customer.customer_id","customer.name","customer.email","customer.address.city","customer.address.country","customer.address.postal_code","payment","metadata")

df = df.withColumn("items",explode_outer("items"))

df = df.select("items.item_id","items.price","items.product_name","items.quantity","order_id","timestamp","customer_id","name","email","city","country","postal_code","payment.method","payment.transaction_id","metadata")

df = df.withColumn("metadata",explode_outer("metadata"))
df = df.select("*","metadata.key","metadata.value").drop("metadata")


# COMMAND ----------

df.writeStream.format("delta")\
        .outputMode("append")\
        .trigger(once=True)\
        .option("path","/Volumes/workspace/stream/streaming/jsonsink/Data")\
        .option("checkpointLocation","/Volumes/workspace/stream/streaming/jsonsink/checkpoint")\
        .start()


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta.`/Volumes/workspace/stream/streaming/jsonsink/Data`

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Archiving**

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/workspace/stream/streaming/jsonsinknew")


# COMMAND ----------

df = spark.readStream.format("json")\
        .option("multiLine",True)\
        .schema(my_schema)\
        .option("cleanSource","archive")\
        .option("sourceArchiveDir","/Volumes/workspace/stream/streaming/jsonsourcearchive")\
        .load("/Volumes/workspace/stream/streaming/jsonsourcenew")


# Transformations
df = df.select("items","order_id","timestamp","customer.customer_id","customer.name","customer.email","customer.address.city","customer.address.country","customer.address.postal_code","payment","metadata")

df = df.withColumn("items",explode_outer("items"))

df = df.select("items.item_id","items.price","items.product_name","items.quantity","order_id","timestamp","customer_id","name","email","city","country","postal_code","payment.method","payment.transaction_id","metadata")

df = df.withColumn("metadata",explode_outer("metadata"))
df = df.select("*","metadata.key","metadata.value").drop("metadata")


# COMMAND ----------

df.writeStream.format("delta")\
        .outputMode("append")\
        .trigger(once=True)\
        .option("path","/Volumes/workspace/stream/streaming/jsonsinknew/Data")\
        .option("checkpointLocation","/Volumes/workspace/stream/streaming/jsonsinknew/checkpoint")\
        .start()


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### READ JSON DATA (BATCH)

# COMMAND ----------

# df = spark.read.format("json")\
#           .option("inferShcema",True)\
#           .option("multiLine",True)\
#           .load("/Volumes/workspace/stream/streaming/jsonsource")

# display(df)

# COMMAND ----------

# df = df.select("items","order_id","timestamp","customer.customer_id","customer.name","customer.email","customer.address.city","customer.address.country","customer.address.postal_code","payment","metadata")

# df = df.withColumn("items",explode_outer("items"))

# display(df)

# COMMAND ----------

# df = df.select("items.item_id","items.price","items.product_name","items.quantity","order_id","timestamp","customer_id","name","email","city","country","postal_code","payment.method","payment.transaction_id","metadata")
# display(df)

# COMMAND ----------

# df = df.withColumn("metadata",explode_outer("metadata"))
# df = df.select("*","metadata.key","metadata.value").drop("metadata")
# display(df)

# COMMAND ----------

