# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.secrets.list(scope='scope-test-learning-awg')

# COMMAND ----------

spark.conf.set("fs.s3a.access.key", dbutils.secrets.get(scope="scope-test-learning-awg", key="aws-accesskey-awg"))
spark.conf.set("fs.s3a.secret.key", dbutils.secrets.get(scope="scope-test-learning-awg", key="aws-secretkey-awg"))
spark.conf.set("fs.s3a.endpoint", "s3.amazonaws.com")

# COMMAND ----------

schemaa = """
USERID INT,
ORDERDATE DATE,
ORDERID LONG,
AMOUNTINFO DOUBLE"""
df = spark.read.format("csv").option("header", "true").schema(schema=schemaa).load("s3a://s3-test-learning-awg/test1141/sales.csv")

# COMMAND ----------

df.show(2)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# spark.conf.set("spark.databricks.delta.logStore.crossCloud.fatal", False)
# Add this to cluster level

# COMMAND ----------

# DBTITLE 1,Untitled
df.groupBy(year(col('ORDERDATE'))).sum('AMOUNTINFO').write.mode('overwrite').format('delta').option("delta.columnMapping.mode", "name").save("s3a://s3-test-learning-awg/test1141/yearly-sales")

# COMMAND ----------

df.groupBy(year(col('ORDERDATE'))).sum('AMOUNTINFO').write.mode('overwrite').format('csv').option('header', 'true').save("s3a://s3-test-learning-awg/test1141/yearly-sales.csv")

# COMMAND ----------

df.groupBy(year(col('ORDERDATE'))).sum('AMOUNTINFO').show()