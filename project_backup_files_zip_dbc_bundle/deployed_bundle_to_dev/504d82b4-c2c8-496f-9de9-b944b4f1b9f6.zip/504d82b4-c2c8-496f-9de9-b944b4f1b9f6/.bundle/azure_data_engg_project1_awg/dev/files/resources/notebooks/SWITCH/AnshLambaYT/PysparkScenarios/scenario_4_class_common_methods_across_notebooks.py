# Databricks notebook source
from pyspark.sql.functions import *
class dataValidation():
    def __init__(self, df):
        self.df = df
    def rename(self, old, new):
        df = self.df.withColumnRenamed(old,new)
        return df


# COMMAND ----------

# df_obj = dataValidation(df)
# df2 = df_obj.rename('customer','customer2')
# display(df2)