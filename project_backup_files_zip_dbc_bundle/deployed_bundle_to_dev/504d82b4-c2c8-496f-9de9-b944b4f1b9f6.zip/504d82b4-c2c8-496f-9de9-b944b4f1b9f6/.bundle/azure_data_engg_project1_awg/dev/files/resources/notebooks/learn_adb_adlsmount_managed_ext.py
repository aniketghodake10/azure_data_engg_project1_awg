# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.storagelevel import StorageLevel

# COMMAND ----------

# DBTITLE 1,Untitled
service_credential = dbutils.secrets.get(scope='scope-test-learning-awg', key='azure-ms-entra-secret-key-vault-governance-awg')
 
spark.conf.set("fs.azure.account.auth.type.datalaketestlearningawg.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.datalaketestlearningawg.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.datalaketestlearningawg.dfs.core.windows.net", "504d82b4-c2c8-496f-9de9-b944b4f1b9f6")
spark.conf.set("fs.azure.account.oauth2.client.secret.datalaketestlearningawg.dfs.core.windows.net", service_credential)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.datalaketestlearningawg.dfs.core.windows.net", "https://login.microsoftonline.com/50a3af05-f42e-4ad1-9203-9b4d0f7b4664/oauth2/token")

# COMMAND ----------

# MAGIC %sql
# MAGIC create catalog man_cata1

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema man_cata1.man_schema1

# COMMAND ----------

# MAGIC %sql
# MAGIC create table man_cata1.man_schema1.man_table1 (id int, name string);
# MAGIC     
# MAGIC insert into man_cata1.man_schema1.man_table1 values (1, 'John'), (2, 'Mary');

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists man_cata1.man_schema1.man_table1;

# COMMAND ----------

# MAGIC %sql
# MAGIC undrop table man_cata1.man_schema1.man_table1;

# COMMAND ----------

# DBTITLE 1,Untitled
# MAGIC %sql
# MAGIC --SET spark.databricks.delta.retentionDurationCheck.enabled = false 
# MAGIC -- This setting should be configured at the cluster or Spark session level, not via SQL.

# COMMAND ----------

# DBTITLE 1,Untitled
# MAGIC %sql
# MAGIC VACUUM man_cata1.man_schema1.man_table1 RETAIN 0 HOURS

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from man_cata1.man_schema1.man_table1

# COMMAND ----------

# MAGIC %sql
# MAGIC create catalog ext_cata1
# MAGIC managed location 'abfss://test-container1@datalaketestlearningawg.dfs.core.windows.net/ext_cata1'

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema ext_cata1.ext_schema1
# MAGIC managed location 'abfss://test-container1@datalaketestlearningawg.dfs.core.windows.net/ext_schema1'

# COMMAND ----------

# MAGIC %sql
# MAGIC create table ext_cata1.ext_schema1.man_table_in_ext_catschema1 (id int, name string);
# MAGIC     
# MAGIC insert into ext_cata1.ext_schema1.man_table_in_ext_catschema1 values (1, 'John'), (2, 'Mary');

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema ext_cata1.man_schema_in_ext_cata1

# COMMAND ----------

# MAGIC %sql
# MAGIC create table ext_cata1.man_schema_in_ext_cata1.man_table_in_ext_cat_man_schema1 (id int, name string);
# MAGIC     
# MAGIC insert into ext_cata1.man_schema_in_ext_cata1.man_table_in_ext_cat_man_schema1 values (1, 'John'), (2, 'Mary');

# COMMAND ----------

dbutils.fs.ls('abfss://test-container2@datalaketestlearningawg.dfs.core.windows.net/')

# COMMAND ----------

dbutils.fs.ls('abfss://test-container3@datalaketestlearningawg.dfs.core.windows.net/')

# COMMAND ----------

dbutils.fs.ls('abfss://test-container3@datalaketestlearningawg.dfs.core.windows.net/')

# COMMAND ----------

dbutils.secrets.list(scope='scope-test-learning-awg')

# COMMAND ----------

dbutils.secrets.get(scope='scope-test-learning-awg', key='azure-ms-entra-secret-key-vault-governance-awg')

# COMMAND ----------

# MAGIC %sql
# MAGIC create table man_cata1.man_schema1.ext_table_in_man_catschema1 (id int, name string)
# MAGIC location 'abfss://test-container1@datalaketestlearningawg.dfs.core.windows.net/man_table_in_man_catschema1';
# MAGIC     
# MAGIC insert into man_cata1.man_schema1.ext_table_in_man_catschema1 values (1, 'John'), (2, 'Mary');

# COMMAND ----------

# MAGIC %sql
# MAGIC create volume man_cata1.man_schema1.man_vol1

# COMMAND ----------

# MAGIC %sql
# MAGIC create external volume man_cata1.man_schema1.ext_vol_in_man_catschema1
# MAGIC location 'abfss://test-container1@datalaketestlearningawg.dfs.core.windows.net/ext_vol_in_man_catschema1';

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from csv.`/Volumes/man_cata1/man_schema1/man_vol1/testdir1/comments.csv`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from csv.`abfss://test-container1@datalaketestlearningawg.dfs.core.windows.net/ext_vol_in_man_catschema1/testdir1/sales.csv`

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history ext_cata1.man_schema_in_ext_cata1.man_table_in_ext_cat_man_schema1

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TBLPROPERTIES ext_cata1.man_schema_in_ext_cata1.man_table_in_ext_cat_man_schema1

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE ext_cata1.man_schema_in_ext_cata1.man_table_in_ext_cat_man_schema1
# MAGIC SET TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from table_changes('ext_cata1.man_schema_in_ext_cata1.man_table_in_ext_cat_man_schema1',0,1)