# Databricks notebook source
print(dbutils.widgets.get("notebook_param1"))

# COMMAND ----------

print(dbutils.widgets.get("job_param1"))

# COMMAND ----------

dbutils.jobs.taskValues.set(key = "fave_food", value = "beans")

# COMMAND ----------

print("ANIKET the BOSS")